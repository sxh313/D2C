export default function App() {
  return (
    <main>
      <div style={{width: '100%', height: '100%', position: 'relative', background: 'white', overflow: 'hidden'}}>
  <img style={{width: 1000, height: 700, left: 0, top: 0, position: 'absolute'}} src="/images/image-2052-3.png" />
</div>
    </main>
  );
}
